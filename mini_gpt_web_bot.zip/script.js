
const chatBox = document.getElementById('chat-box');
const input = document.getElementById('user-input');

const memory = [];
let lastUser = "";

function sendMessage() {
    const userText = input.value.trim();
    if (!userText) return;
    appendMessage("Ты", userText);
    input.value = "";

    const response = generateResponse(userText);
    appendMessage("Бот", response);
}

function appendMessage(sender, text) {
    const msg = document.createElement('div');
    msg.innerHTML = `<strong>${sender}:</strong> ${text}`;
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
}

function generateResponse(text) {
    const lowered = text.toLowerCase();

    if (lowered.includes("тупой")) return "Скажи это своей маме 😎";
    if (lowered.startsWith("запомни")) {
        const toRemember = text.slice(7).trim();
        memory.push(toRemember);
        return `Хорошо, я запомнил: "${toRemember}"`;
    }
    if (lowered.includes("кто тебя создал")) return "Меня создал MrFenre";
    if (lowered.includes("твоя любимая игра")) return "Project Zomboid конечно же!";
    if (lowered.includes("знаешь другие нейросети")) return "Да! ChatGPT, Gemini, Claude и другие.";
    if (lowered.includes("какой код")) return "Я пока не знаю, но в будущем буду знать!";
    if (lowered.includes("создай кнопку в годот")) return "Создай кнопку и добавь сигнал 'pressed', затем напиши get_tree().quit() или другой код.";
    if ((text.match(/ок/gi) || []).length >= 3) return "Прикрати пожалуйста говорить 'ок'";
    
    return "Хорошо! Что ещё ты хочешь?";
}
